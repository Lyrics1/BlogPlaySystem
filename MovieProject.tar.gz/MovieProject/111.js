{
			title:'猫和老鼠',
			_id:1,
			poster:'../image/2.jpg'
		},{
			title:'猫和老鼠',
			_id:2,
			poster:'../image/1.jpg'
		},{
			title:'猫和老鼠',
			_id:3,
			poster:'../image/1.jpg'
		},{
			title:'猫和老鼠',
			_id:4,
			poster:'../image/1.jpg'
		},{
			title:'猫和老鼠',
			_id:5,
			poster:'../image/1.jpg'
		},{
			title:'猫和老鼠',
			_id:6,
			poster:'../image/1.jpg'
		}




		[{
			title:"动画片",
			doctor:"Lyrics",
			country:"中国",
			language:"汉语",
			year:"1997",
			summary:"好看卡卡",
			flash:"../video/陈奕迅 - 让我留在你身边.mp4"
		},{
			title:"动画片",
			doctor:"Lyrics",
			country:"中国",
			language:"汉语",
			year:"1997",
			summary:"好看卡卡",
			flash:"../video/周杰伦 - 床边故事.mp4"
		},{
			title:"动画片",
			doctor:"Lyrics",
			country:"中国",
			language:"汉语",
			year:"1997",
			summary:"好看卡卡",
			flash:"../video/尚雯婕 - 鹿 be free.mp4"
		},{
			title:"动画片",
			doctor:"Lyrics",
			country:"中国",
			language:"汉语",
			year:"1997",
			summary:"好看卡卡",
			flash:"../video/ゆめこ - 夏令时记录(piano.ver).mp4"
		}]