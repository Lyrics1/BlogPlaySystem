var config ={
	host:'localhost',
	user:'root',
	password:'',
	database:'imooc'

}

module.exports = config; 
